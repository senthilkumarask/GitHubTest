package com.bbb.integration.qas;

import atg.qas.QasAddressVerificationSearch;

import com.bbb.constants.BBBCoreConstants;
import com.bbb.utils.BBBConfigRepoUtils;
import com.bbb.utils.BBBUtility;

public class BBBQasAddressVerificationSearch extends QasAddressVerificationSearch {

	protected String onDemandUsername;
	protected String onDemandPassword;
	
	@Override
	public String getOnDemandUsername() {
		if(BBBUtility.isEmpty(this.onDemandUsername))
		{
			this.onDemandUsername = BBBConfigRepoUtils.getStringValue(BBBCoreConstants.THIRD_PARTY_URL, BBBCoreConstants.ON_DEMAND_UNAME);
		}
		System.out.println("Username in BBBQasAddressVerificationSearch is  : " + onDemandUsername);
		return this.onDemandUsername;
	}
	
	@Override
	public String getOnDemandPassword() {
				if(BBBUtility.isEmpty(this.onDemandPassword))
		{
			this.onDemandPassword = BBBConfigRepoUtils.getStringValue(BBBCoreConstants.THIRD_PARTY_URL, BBBCoreConstants.ON_DEMAND_PSWD);
		}
		System.out.println("Password in BBBQasAddressVerificationSearch is  : " + onDemandPassword);
		return this.onDemandPassword;
	}
}
